package Polymorphism;

public class Dynamic_2 extends Dynamic_Polymorphism {
	void show_child() {
		System.out.println("Inside Dynamic_2[Child] class show_child method");
	}

}
