package Polymorphism;

public class Static_Polymorphism {
	int a;
	double b;
	char c;
	String d;
	public Static_Polymorphism() {
		System.out.println("Default Constructor");
		a = 5;
		b = 4.9876;
		c ='p';
	}
	public Static_Polymorphism(int p, String q) {
		System.out.println("Parameterized Constructor");
		a = p;
		d = q;
		
	}
	void displayData() {
		System.out.println("A: " + a + " B: " + b + " C: " + c + " D: " + d);
	}

}
