package Polymorphism;

public class Dynamic_Polymorphism {
	int num = 50;
	void show_parent() {
		System.out.println("Show Parent's data");
		System.out.println("Num:"+num);
	}

}
