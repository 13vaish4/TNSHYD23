package Polymorphism;

public class Dynamic_Main {

	public static void main(String[] args) {
		Dynamic_Polymorphism d1 = new Dynamic_Polymorphism();
		d1.show_parent();
		Dynamic_2 d2 = new Dynamic_2();
		d2.show_child();

	}

}
