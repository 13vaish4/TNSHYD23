package Polymorphism;

public class Static_Main {

	public static void main(String[] args) {
		Static_Polymorphism s1 = new Static_Polymorphism();
        s1.displayData(); // Displays the data for the default constructor

        Static_Polymorphism s2 = new Static_Polymorphism(5, "App");
        s2.displayData(); // Displays the data for the parameterized constructor

	}

}
