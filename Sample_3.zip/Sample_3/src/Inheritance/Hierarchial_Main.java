package Inheritance;

public class Hierarchial_Main extends Hierarchial {
	void act() {
		System.out.println("Act the way that suits the overall situation.");
	}

	public static void main(String[] args) {
		Hierarchial_Main h1 = new Hierarchial_Main();
		h1.observe();
		//h1.interpret(); Error
		h1.act();

	}

}
