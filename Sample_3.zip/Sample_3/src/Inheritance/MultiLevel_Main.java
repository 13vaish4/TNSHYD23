package Inheritance;

public class MultiLevel_Main extends MultiLevel_2 {
	void talk() {
		System.out.println("Whatever you understood try to explain to other people.");
	}

	public static void main(String[] args) {
		MultiLevel_Main m1 = new MultiLevel_Main();
		m1.read();
		m1.understand();
		m1.talk();
		

	}

}
