package Inheritance;


public class SingleMain extends Single {
	void plan() {
		System.out.println("After listening, plan accordingly");
	}

	public static void main(String[] args) {
		SingleMain s1 = new SingleMain();
		s1.listen();
		s1.plan();

		

	}

}
