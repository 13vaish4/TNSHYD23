package Inheritance;

public class Hierarchial {
	void observe() {
		System.out.println("See the situattion properly");
	}

}
