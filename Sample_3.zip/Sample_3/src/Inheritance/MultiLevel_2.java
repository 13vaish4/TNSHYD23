package Inheritance;

public class MultiLevel_2 extends MultiLevel{
	void understand() {
		System.out.println("Understand the Meaning of what you read.");
	}

}
