package Inheritance;

public class Hierarchial_2 extends Hierarchial {
	void interpret() {
		System.out.println("Underatand situation properly.");
	}

}
