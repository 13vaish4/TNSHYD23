package Inheritance;

public class Single {
	void listen() {
		System.out.println("Listen carefully");
	}

}
