package Inheritance;

public class MultiLevel {
	void read() {
		System.out.println("Read clearly");
	}

}
