package Constructor;

public class Parameterized_Emp {
	String name;
	int Salary;
	public Parameterized_Emp(String x, int y) {
		name = x;
		Salary = y;
	}

}
