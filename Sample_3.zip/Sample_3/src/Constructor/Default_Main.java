package Constructor;


public class Default_Main {

	public static void main(String[] args) {
		Default_Emp e1 = new Default_Emp();
		System.out.println(e1.Salary);
		System.out.println(e1.name);


	}

}
