package Constructor;

public class Parameterized_Main {

	public static void main(String[] args) {
		Parameterized_Emp e1 = new Parameterized_Emp("Monkey",100000);
		System.out.println(e1.name);
		System.out.println(e1.Salary);

	}

}
