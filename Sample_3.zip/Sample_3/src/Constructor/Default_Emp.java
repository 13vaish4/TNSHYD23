package Constructor;

public class Default_Emp {
	int Salary;
	String name;

public Default_Emp() {
	Salary = 80000;
	name = "Monkey";
	}

}
