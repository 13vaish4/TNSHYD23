package tns.oop;

public class Voter {
	private String name; 
	public  int age;

}
