package tns.oop;

public class Eligible2 {
	public static void main(String[] args) {
		Voter2 v2 = new Voter2();
		v2.setname("Monkey");
		System.out.println(v2.getname());
		v2.setage(25);
		System.out.println(v2.getage());
	}

}
