package tns.oop;

public class Eligible1 {

	public static void main(String[] args) {
		Voter1 v1 = new Voter1();
		v1.setname("Monkey");
		v1.setage(25);
		System.out.println(v1.check());

	}

}
