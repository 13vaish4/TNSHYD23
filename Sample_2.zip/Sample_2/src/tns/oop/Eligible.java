package tns.oop;

public class Eligible {
	public static void main(String[] args) {
		Voter v1 = new Voter();
		v1.age = 25;
		System.out.println(v1.age);
	}

}
