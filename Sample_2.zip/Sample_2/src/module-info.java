/**
 * 
 */
/**
 * 
 */
module Sample_2 {
}