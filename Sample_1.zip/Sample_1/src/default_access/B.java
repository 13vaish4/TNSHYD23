package default_access;

public class B {           //within package two classes are created B and C
	void display() {              //Default access Specifier can be accesed within  the package
		System.out.println(20025);
	}

}