package default_access;

public class C {

	public static void main(String[] args) {
		B b1 = new B();
		b1.display();

	}

}
