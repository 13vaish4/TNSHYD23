package user_endpack;

import user_defined_pack.*;
import user_subpack.*;

public class E {

	public static void main(String[] args) {
		A obj1 = new A();
		D obj2 = new D();
		obj1.msg();
		obj2.msg();
		

	}

}
