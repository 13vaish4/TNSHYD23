package private_access;

public class A {                      
	private void display() {         //(Instance method) Private Access Modifier can be accessed within the class
		System.out.println("TNS Session");
		}

	public static void main(String[] args) {
		A a1 = new A();
		a1.display();    //accessing instance method attributes

	}

}
