package user_defined_pack;

public class A {
	public void msg() {
		System.out.println("Hello A");
	}

}
