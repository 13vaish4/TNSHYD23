package protectedaccess1;
import protected_access.*;

public class E extends D {     //using inheritance concept  

	public static void main(String[] args) {
		E e1 = new E();
		e1.display();

	}
	
}
