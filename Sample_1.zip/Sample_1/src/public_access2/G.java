package public_access2;
import public_access1.*;


public class G {       //PublicAccess

	public static void main(String[] args) {
		F f1 = new F();
		f1.display();

	}

}