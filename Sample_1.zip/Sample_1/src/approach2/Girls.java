package approach2;

public class Girls {
	public static void main(String[] args) {
		Boys b1 = new Boys();
		System.out.println(b1.b);
		b1.avg();
		System.out.println(Boys.c);
		Boys.total();
		
	}

}
