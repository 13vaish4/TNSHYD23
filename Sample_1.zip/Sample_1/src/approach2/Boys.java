package approach2;

public class Boys {
	int b = 30;
	static int c = 50;
	
	int avg() {
		return 40;
	}
	static void total() {
		System.out.println(80);
	}

}
