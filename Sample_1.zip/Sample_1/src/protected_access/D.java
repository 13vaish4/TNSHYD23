package protected_access;

public class D {
	
	protected void display() {  //Protected Access Specifier can be accessed within and outside the package through inheritance
		System.out.println("This is protected access specifier");
	}

}
