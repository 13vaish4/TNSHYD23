package public_access1;

public class F {        //Public Access Specifier can be accessed from anywhere
	public void display() {
		System.out.println("TNS Batch-23");
	}

}

