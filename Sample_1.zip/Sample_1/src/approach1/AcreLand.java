package approach1;

public class AcreLand {
	int b = 50;
	static int c = 100;
	int display() {
		return 60;
	}
	static void play() {
		System.out.println(85);
	}

	public static void main(String[] args) {
		int a = 150;
		System.out.println(a);
		AcreLand a1 = new AcreLand();
		System.out.println(a1.b);
		a1.display();
		System.out.println(AcreLand.c);
		AcreLand.play();
		

	}

}