package user_subpack;

public class D {
	public void msg() {
		System.out.println("Hello D");
	}

}
