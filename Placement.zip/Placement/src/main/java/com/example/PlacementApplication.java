package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementApplication.class, args);
	}

}
