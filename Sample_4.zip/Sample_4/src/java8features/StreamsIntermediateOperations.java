package java8features;
import java.util.*;
import java.util.stream.*;

public class StreamsIntermediateOperations {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        // Filter even numbers
        List<Integer> evenNumbers = numbers.stream()
                                         .filter(n -> n % 2 == 0)
                                         .collect(Collectors.toList());

        // Map numbers to their squares
        List<Integer> squaredNumbers = numbers.stream()
                                            .map(n -> n * n)
                                            .collect(Collectors.toList());

        // FlatMap a list of lists
        List<List<Integer>> nestedLists = Arrays.asList(Arrays.asList(1, 2), Arrays.asList(3, 4));
        List<Integer> flattenedList = nestedLists.stream()
                                                .flatMap(List::stream)
                                                .collect(Collectors.toList());

        // Sort numbers in descending order
        List<Integer> sortedNumbers = numbers.stream()
                                            .sorted(Comparator.reverseOrder())
                                            .collect(Collectors.toList());

        // Distinct numbers
        List<Integer> numbersWithDuplicates = Arrays.asList(1, 2, 3, 2, 1);
        List<Integer> distinctNumbers = numbersWithDuplicates.stream()
                                                            .distinct()
                                                            .collect(Collectors.toList());

        // Print the results
        System.out.println("Even numbers: " + evenNumbers);
        System.out.println("Squared numbers: " + squaredNumbers);
        System.out.println("Flattened list: " + flattenedList);
        System.out.println("Sorted numbers: " + sortedNumbers);
        System.out.println("Distinct numbers: " + distinctNumbers);

	}

}
