package java8features;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


public class StreamTerminalOperations {

	public static void main(String[] args) {
	        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

	        // Find the sum of numbers
	        int sum = numbers.stream()
	                         .reduce(0, Integer::sum);

	        // Find the maximum number (consider using Integer.MIN_VALUE for empty stream)
	        int max = numbers.stream()
	                         .max(Integer::compare)
	                         .orElse(Integer.MIN_VALUE);

	        // Find the minimum number (consider using a custom message for empty stream)
	        int min = numbers.stream()
	                         .min(Integer::compare)
	                         .orElse(Integer.MAX_VALUE); // could be a custom message as well

	        // Check if all numbers are even
	        boolean allEven = numbers.stream()
	                                .allMatch(n -> n % 2 == 0);

	        // Check if any number is even
	        boolean anyEven = numbers.stream()
	                                .anyMatch(n -> n % 2 == 0);

	        // Count the number of even numbers
	        long countEven = numbers.stream()
	                               .filter(n -> n % 2 == 0)
	                               .count();

	        // Collect numbers into a list
	        List<Integer> collectedNumbers = numbers.stream()
	                                                .collect(Collectors.toList());

	        // Collect numbers into a set
	        Set<Integer> collectedSet = numbers.stream()
	                                          .collect(Collectors.toSet());

	        // Collect numbers into a map, grouping by their parity
	        Map<Boolean, List<Integer>> groupedByParity = numbers.stream()
	                                                            .collect(Collectors.partitioningBy(n -> n % 2 == 0));

	        // Print the results
	        System.out.println("Sum: " + sum);
	        System.out.println("Maximum: " + max);
	        System.out.println("Minimum: " + min);
	        System.out.println("All even: " + allEven);
	        System.out.println("Any even: " + anyEven);
	        System.out.println("Count even: " + countEven);
	        System.out.println("Collected numbers: " + collectedNumbers);
	        System.out.println("Collected set: " + collectedSet);
	        System.out.println("Grouped by parity: " + groupedByParity);

	}

}
