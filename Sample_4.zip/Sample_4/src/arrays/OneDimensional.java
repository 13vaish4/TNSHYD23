package arrays;

public class OneDimensional {

	public static void main(String[] args) {
		int a[] = new int[3];
		a[0] = 0;
		a[1] = 100;
		a[2] = 200;
		
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]);
		}

	}

}
