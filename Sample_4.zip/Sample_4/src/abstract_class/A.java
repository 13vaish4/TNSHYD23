package abstract_class;

public abstract class A {
	int a = 5;
	int b = 10;
	abstract void display();

}
