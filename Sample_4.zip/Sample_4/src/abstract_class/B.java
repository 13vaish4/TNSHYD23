package abstract_class;

public class B extends A {
	void display() {
		System.out.println("First Value is: "+ a);
	}

}
