package abstract_class;

public class C extends A {
	void display() {
		System.out.println("Second Value is:"+b);
	}

}
