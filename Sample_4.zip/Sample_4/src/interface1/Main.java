package interface1;

public class Main {

	public static void main(String[] args) {
		A a1 = new B();
		a1.display();
		A a2 = new C();
		a2.display();

	}

}
