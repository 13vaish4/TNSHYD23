package interface1;

public interface A {
	void display();//       {[Abstract methods does not specify body]}
		//System.out.println("Hello");
	//}

}
