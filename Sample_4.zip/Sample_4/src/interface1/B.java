package interface1;

public class B implements A {
	public void display() {
		System.out.println("Prints value");
	}

}
