package interface1;

public class C implements A {
	public void display() {
		System.out.println("Prints extended value");
	}

}
