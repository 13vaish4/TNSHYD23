package keywords;

public class FinalVariable {
    final int salary = 100;
    public void run() {
    	int salary= 500;
    	System.out.println(salary);
    }
    public static void main(String[] args) {

    	FinalVariable f1 = new FinalVariable();
    	//f1.run();
    	System.out.println(f1.salary);
    	
	}

}

