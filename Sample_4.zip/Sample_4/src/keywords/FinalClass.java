package keywords;

public final class FinalClass {
	
}
