package keywords;

public class FinalMain {

	public static void main(String[] args) {
			FinalClass1 f1 = new FinalClass1();
			f1.run();

	}

}
