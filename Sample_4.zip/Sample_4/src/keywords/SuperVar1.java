package keywords;

public class SuperVar1 extends SuperVariable {
	int size = 100;
	void printSize() {
		System.out.println(size);   //prints col of SuperVar1 class
		System.out.println(super.size);   //prints color of SuperVariable class
	}

}
