package keywords;

public class FinalMethod {
	final void display() {
		System.out.println("Hello");
	}
	class B{
		void display(){
			System.out.println("Hello World!");
			
		}
	}

	public static void main(String[] args) {
		FinalMethod f1 = new FinalMethod();
		f1.display();
	}

}
