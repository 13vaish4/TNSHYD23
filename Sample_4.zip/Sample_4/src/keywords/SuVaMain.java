package keywords;

public class SuVaMain {

	public static void main(String[] args) {
		SuperVar1 su = new SuperVar1();
		su.printSize();

	}

}
