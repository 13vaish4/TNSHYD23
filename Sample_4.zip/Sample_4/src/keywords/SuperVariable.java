package keywords;

public class SuperVariable {
	int size = 50;

}
