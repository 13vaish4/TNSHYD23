package keywords;

public class SuperMethod {
	

}
