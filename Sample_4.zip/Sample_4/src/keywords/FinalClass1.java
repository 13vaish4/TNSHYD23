package keywords;

public class FinalClass1 extends FinalClass {
	void run() {
		System.out.println("Hello World!");
	}
	
}
