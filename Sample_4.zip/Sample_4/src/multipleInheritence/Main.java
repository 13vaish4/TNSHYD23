package multipleInheritence;

public class Main  {
	public static void main(String[] args) {
		Main m1= new Main();
		m1.display();

	}

}
