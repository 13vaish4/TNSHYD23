package multipleInheritence;

public class C extends A {
	public void display() {
		System.out.println("Hello beautiful world!");
	}


}
