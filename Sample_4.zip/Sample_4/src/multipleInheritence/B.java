package multipleInheritence;

public class B  extends A {
	public void display() {
		System.out.println("Hello beautiful!");
	}

}
