package methods;

public class Bb implements AaDefault{

	public int display() {
		
		return 10;
	}
	

}
