package methods;

public class Cc implements AaDefault{

	public int display() {
		
		return 20;
	}
	

}
