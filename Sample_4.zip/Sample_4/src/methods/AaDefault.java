package methods;

public interface AaDefault {
	int display();
	default int display1() {
		return 40;
	}

}
