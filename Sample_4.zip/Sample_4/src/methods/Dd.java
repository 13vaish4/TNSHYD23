package methods;

public class Dd implements AaDefault{
	public int display() {
		return 30;
	}
	public int display1() {
		return 50;
	}
	public static void main(String[] args) {
		AaDefault a1 = new Bb();
		System.out.println(a1.display());
		System.out.println(a1.display1());
		
		AaDefault a2 = new Cc();
		System.out.println(a2.display());
		System.out.println(a2.display1());
		
		AaDefault a3 = new Dd();
		System.out.println(a3.display());
		System.out.println(a3.display1());
	}

}
