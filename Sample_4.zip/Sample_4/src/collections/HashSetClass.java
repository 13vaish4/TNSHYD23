package collections;
import java.util.*;

public class HashSetClass {

	public static void main(String[] args) {
		HashSet<String>hs = new HashSet<String>();
		
		hs.add("Hello");
		hs.add("to");
		hs.add("everyone");
		hs.add("Hello");
		hs.add("World");
		Iterator<String> itr = hs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
