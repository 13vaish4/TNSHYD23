package collections;
import java.util.*;

public class StackList {

	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();
		stack.push("Hello");
		stack.push("Beautiful");
		stack.push("Hello");
		stack.push("World");
		
		Iterator<String>itr = stack.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next()+" ");
		}
			System.out.println();
			stack.pop();
			stack.pop();
			itr = stack.iterator();
			while(itr.hasNext()) {
				System.out.println(itr.next()+" ");
			
			}
		}
	}


