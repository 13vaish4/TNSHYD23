package collections;
import java.util.*;

public class PriorityQue {

	public static void main(String[] args) {
		PriorityQueue<Integer> pQueue = new PriorityQueue<Integer>();
		
		pQueue.add(10);
		pQueue.add(20);
		pQueue.add(30);
		
		System.out.println(pQueue.peek());  //Printing top element
		System.out.println(pQueue.poll());  //Printing top element & removing it
		
		System.out.println(pQueue.peek());

	}

}
