package collections;
import java.util.*;

public class HashMapClass {

	public static void main(String[] args) {
		HashMap<Integer,String>hm = new HashMap<Integer,String>();
		
		hm.put(1, "Hello");
		hm.put(2, "the");
		hm.put(3, "Wonderful");
		hm.put(4, "World");
		
		System.out.println("Value for 1 is " + hm.get(1));
		
		for(Map.Entry<Integer,String>e: hm.entrySet())
			System.out.println(e.getKey()+ " "+ e.getValue());

	}

}
